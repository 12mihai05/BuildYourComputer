<!DOCTYPE html>
<html lang="en">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Product Filter And Search</title>
    <!-- Google Font -->
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&display=swap"
      rel="stylesheet"
    />
    <!-- Stylesheet -->
    <link rel="stylesheet" href="css/form.css" />
  </head>
  <body>
    <div class="wrapper">
      <form  action="form.php" method="post">
        <input type="text" name="search" placeholder="Search product name here.." required>
        <input type="submit" value="Search">
      </form>
    </div>

      <?php
      if (isset($_POST["search"])) {
        require "search.php";

        if (count($results)>0) {
          foreach ($results as $row) { ?>
            <div class="card">
              <div class="image">
                <img src="<?php echo $row["image"]; ?>" alt="">
              </div>
              <div class="caption">
                <p class="product_name"><?php echo $row["type"],$row["name"] ?></p>
                <p class="product_model"><?php echo $row["model"] ?></p>
                <p class="price"><b>$ <?php echo $row["price"] ?></b></p>
              </div>
              <button class="add">Add to cart</button>
            </div>
          <?php }
        } else {
            echo "No results found";
        }
      }
      ?>

  </body>
</html>
